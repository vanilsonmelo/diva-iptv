# -*- coding: utf-8 -*-
import os
import sys
import json
import time
import urllib.request
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE = sys.argv[0]
ARGS = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
MEDIA = ADDON.getAddonInfo('path') + '/resources/media/'
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
STATE_FILE = os.path.join(PROFILE, 'state.json')

WATCHED_AT = 0.90    # a partir de 90% conta como assistido
MIN_RESUME = 30      # só guarda ponto de retomada depois de 30 s


# ---------------------------------------------------------------- utilidades
def log(msg):
    xbmc.log('[DivaIPTV] %s' % msg, xbmc.LOGINFO)


def notify(msg, error=False):
    icon = xbmcgui.NOTIFICATION_ERROR if error else xbmcgui.NOTIFICATION_INFO
    xbmcgui.Dialog().notification('Diva IPTV', msg, icon, 4000)


def fmt_time(sec):
    sec = int(sec)
    h, rest = divmod(sec, 3600)
    m, s = divmod(rest, 60)
    return '%d:%02d:%02d' % (h, m, s) if h else '%02d:%02d' % (m, s)


def link(**kw):
    return BASE + '?' + urllib.parse.urlencode(kw)


def as_list(data):
    return data if isinstance(data, list) else []


def to_int(v):
    try:
        return int(v)
    except Exception:
        return 0


# --------------------------------------------------------------------- estado
def load_state():
    try:
        with open(STATE_FILE, 'r', encoding='utf-8') as f:
            s = json.load(f)
    except Exception:
        s = {}
    s.setdefault('resume', {})
    s.setdefault('watched', {})
    s.setdefault('current', {})
    return s


def save_state(s):
    try:
        if not xbmcvfs.exists(PROFILE):
            xbmcvfs.mkdirs(PROFILE)
        tmp = STATE_FILE + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(s, f)
        os.replace(tmp, STATE_FILE)
    except Exception as e:
        log('erro ao salvar estado: %s' % e)


# ------------------------------------------------------------------------ API
def cfg():
    server = ADDON.getSetting('server').strip().rstrip('/')
    if server and not server.startswith('http'):
        server = 'http://' + server
    return server, ADDON.getSetting('username').strip(), ADDON.getSetting('password').strip()


def user_agent():
    ua = ADDON.getSetting('useragent').strip()
    return ua or 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36'


def api(action, **params):
    server, user, pwd = cfg()
    if not (server and user and pwd):
        xbmcgui.Dialog().ok('Diva IPTV', 'Preencha servidor, usuário e senha nas configurações do addon.')
        ADDON.openSettings()
        return None
    q = {'username': user, 'password': pwd}
    if action:
        q['action'] = action
    q.update(params)
    url = '%s/player_api.php?%s' % (server, urllib.parse.urlencode(q))
    try:
        req = urllib.request.Request(url, headers={'User-Agent': user_agent()})
        with urllib.request.urlopen(req, timeout=40) as r:
            return json.loads(r.read().decode('utf-8', 'replace'))
    except Exception as e:
        notify('Erro: %s' % e, True)
        log('erro de API: %s' % e)
        return None


def api_cached(action, ttl=600, **params):
    name = 'cache_%s_%s.json' % (action, params.get('category_id', 'all'))
    path = os.path.join(PROFILE, name)
    try:
        if os.path.exists(path) and time.time() - os.path.getmtime(path) < ttl:
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception:
        pass
    data = api(action, **params)
    if data is not None:
        try:
            if not xbmcvfs.exists(PROFILE):
                xbmcvfs.mkdirs(PROFILE)
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(data, f)
        except Exception:
            pass
    return data


def live_ext():
    return ADDON.getSetting('live_format') or 'ts'


def stream_url(kind, sid, ext):
    server, user, pwd = cfg()
    folder = {'live': 'live', 'vod': 'movie', 'ep': 'series'}[kind]
    base = '%s/%s/%s/%s/%s.%s' % (server, folder, user, pwd, sid, ext)
    return base + '|User-Agent=' + urllib.parse.quote(user_agent())


# ---------------------------------------------------------- itens e marcações
def key_of(kind, sid):
    return '%s:%s' % (kind, sid)


def play_params(kind, sid, ext, title, icon='', series='', season='', cat='', sname=''):
    return {'kind': kind, 'id': str(sid), 'ext': ext or '', 'title': title or '', 'icon': icon or '',
            'series': str(series or ''), 'season': str(season or ''), 'cat': str(cat or ''),
            'sname': sname or ''}


def play_link(p):
    return link(mode='play', **p)


def make_item(title, art=None, plot='', playable=False, key=None, state=None):
    label = title
    playcount = 0
    resume = None
    if key and state:
        if key in state['watched']:
            playcount = 1
            label = '[COLOR gray]%s[/COLOR]' % title
        elif key in state['resume']:
            r = state['resume'][key]
            resume = r
            if r.get('total'):
                label = '%s [COLOR yellow](%d%%)[/COLOR]' % (title, int(100 * r['pos'] / r['total']))
    li = xbmcgui.ListItem(label=label)
    if art:
        li.setArt({'thumb': art, 'icon': art, 'poster': art})
    try:
        tag = li.getVideoInfoTag()
        tag.setTitle(title)
        if plot:
            tag.setPlot(plot)
        if playcount:
            tag.setPlaycount(1)
        if resume and resume.get('total'):
            tag.setResumePoint(float(resume['pos']), float(resume['total']))
    except Exception:
        info = {'title': title, 'plot': plot}
        if playcount:
            info['playcount'] = 1
        li.setInfo('video', info)
    if playable:
        li.setProperty('IsPlayable', 'true')
    if key and not key.startswith('live:'):
        li.addContextMenuItems([
            ('Marcar como assistido', 'RunPlugin(%s)' % link(mode='mark', key=key, val='1')),
            ('Marcar como não assistido', 'RunPlugin(%s)' % link(mode='mark', key=key, val='0')),
        ])
    return li


def finish(content=None):
    if content:
        xbmcplugin.setContent(HANDLE, content)
    xbmcplugin.endOfDirectory(HANDLE)


# ------------------------------------------------------------------- navegação
KEYMAP = """<keymap>
  <FullscreenVideo>
    <keyboard>
      <return>RunPlugin(plugin://%(id)s/?mode=menu)</return>
      <enter>RunPlugin(plugin://%(id)s/?mode=menu)</enter>
      <pageup>RunPlugin(plugin://%(id)s/?mode=next)</pageup>
      <pagedown>RunPlugin(plugin://%(id)s/?mode=prev)</pagedown>
    </keyboard>
    <remote>
      <select>RunPlugin(plugin://%(id)s/?mode=menu)</select>
      <pageplus>RunPlugin(plugin://%(id)s/?mode=next)</pageplus>
      <pageminus>RunPlugin(plugin://%(id)s/?mode=prev)</pageminus>
    </remote>
  </FullscreenVideo>
</keymap>
""" % {'id': ADDON_ID}


def ensure_keymap():
    try:
        folder = xbmcvfs.translatePath('special://userdata/keymaps/')
        path = os.path.join(folder, 'xtreamvod.xml')
        if xbmcvfs.exists(path):
            f = xbmcvfs.File(path)
            old = f.read()
            f.close()
            if old == KEYMAP:
                return
        if not xbmcvfs.exists(folder):
            xbmcvfs.mkdirs(folder)
        f = xbmcvfs.File(path, 'w')
        f.write(KEYMAP)
        f.close()
        xbmc.executebuiltin('Action(reloadkeymaps)')
    except Exception as e:
        log('keymap: %s' % e)


def root():
    ensure_keymap()
    items = [
        ('Continuar assistindo', link(mode='continue'), 'resume.png'),
        ('Canais ao vivo', link(mode='live_cats'), 'live.png'),
        ('Filmes', link(mode='vod_cats'), 'movies.png'),
        ('Séries', link(mode='series_cats'), 'series.png'),
        ('Minha conta', link(mode='account'), 'settings.png'),
        ('Atualizar addon', link(mode='update'), 'settings.png'),
        ('Configurações', link(mode='settings'), 'settings.png'),
    ]
    for name, url, img in items:
        xbmcplugin.addDirectoryItem(HANDLE, url, make_item(name, MEDIA + img), True)
    finish()


def categories(action, mode_next, img):
    data = as_list(api(action))
    data.sort(key=lambda c: (c.get('category_name') or '').lower())
    entries = []
    for c in data:
        url = link(mode=mode_next, cat=c.get('category_id'))
        entries.append((url, make_item(c.get('category_name') or 'Sem nome', MEDIA + img), True))
    xbmcplugin.addDirectoryItems(HANDLE, entries, len(entries))
    finish()


def live_list(cat):
    data = as_list(api_cached('get_live_streams', category_id=cat))
    data.sort(key=lambda c: to_int(c.get('num')))
    entries = []
    for c in data:
        p = play_params('live', c.get('stream_id'), live_ext(), c.get('name') or 'Sem nome',
                        c.get('stream_icon'), cat=cat)
        li = make_item(p['title'], p['icon'], playable=True, key=key_of('live', p['id']))
        entries.append((play_link(p), li, False))
    xbmcplugin.addDirectoryItems(HANDLE, entries, len(entries))
    finish('videos')


def vod_list(cat):
    st = load_state()
    data = as_list(api('get_vod_streams', category_id=cat))
    data.sort(key=lambda m: (m.get('name') or '').lower())
    entries = []
    for m in data:
        p = play_params('vod', m.get('stream_id'), m.get('container_extension') or 'mp4',
                        m.get('name') or 'Sem nome', m.get('stream_icon'), cat=cat)
        li = make_item(p['title'], p['icon'], playable=True, key=key_of('vod', p['id']), state=st)
        entries.append((play_link(p), li, False))
    xbmcplugin.addDirectoryItems(HANDLE, entries, len(entries))
    finish('movies')


def series_list(cat):
    data = as_list(api('get_series', category_id=cat))
    data.sort(key=lambda s: (s.get('name') or '').lower())
    entries = []
    for s in data:
        url = link(mode='seasons', series=s.get('series_id'), sname=s.get('name') or '')
        li = make_item(s.get('name') or 'Sem nome', s.get('cover'), s.get('plot') or '')
        entries.append((url, li, True))
    xbmcplugin.addDirectoryItems(HANDLE, entries, len(entries))
    finish('tvshows')


def get_episodes(series_id):
    info = api('get_series_info', series_id=series_id)
    if not isinstance(info, dict):
        return {}
    eps = info.get('episodes') or {}
    if isinstance(eps, list):
        grouped = {}
        for e in eps:
            grouped.setdefault(str(e.get('season', 1)), []).append(e)
        eps = grouped
    return eps


def ep_params(e, season, series_id, sname):
    info = e.get('info') or {}
    title = 'T%sE%s - %s' % (season, e.get('episode_num'), e.get('title') or 'Episódio')
    return play_params('ep', e.get('id'), e.get('container_extension') or 'mp4', title,
                       info.get('movie_image'), series=series_id, season=season, sname=sname)


def seasons(series_id, sname):
    eps = get_episodes(series_id)
    keys = sorted(eps.keys(), key=lambda k: to_int(k))
    entries = []
    for k in keys:
        url = link(mode='episodes', series=series_id, season=k, sname=sname)
        entries.append((url, make_item('Temporada %s' % k, MEDIA + 'series.png'), True))
    xbmcplugin.addDirectoryItems(HANDLE, entries, len(entries))
    finish('seasons')


def episodes(series_id, season, sname):
    st = load_state()
    eps = list(get_episodes(series_id).get(season, []))
    eps.sort(key=lambda e: to_int(e.get('episode_num')))
    entries = []
    for e in eps:
        p = ep_params(e, season, series_id, sname)
        info = e.get('info') or {}
        label = '%s. %s' % (e.get('episode_num'), e.get('title') or 'Episódio')
        li = make_item(label, p['icon'], info.get('plot') or '', playable=True,
                       key=key_of('ep', p['id']), state=st)
        entries.append((play_link(p), li, False))
    xbmcplugin.addDirectoryItems(HANDLE, entries, len(entries))
    finish('episodes')


def continue_list():
    st = load_state()
    rows = sorted(st['resume'].items(), key=lambda kv: -kv[1].get('ts', 0))[:60]
    entries = []
    for key, r in rows:
        p = r.get('params')
        if not p:
            continue
        label = p['title']
        if p.get('sname'):
            label = '%s - %s' % (p['sname'], label)
        li = make_item(label, p.get('icon'), playable=True, key=key, state=st)
        entries.append((play_link(p), li, False))
    if not entries:
        notify('Nada em andamento ainda.')
    xbmcplugin.addDirectoryItems(HANDLE, entries, len(entries))
    finish('videos')


def mark():
    key = ARGS.get('key')
    st = load_state()
    if ARGS.get('val') == '1':
        st['watched'][key] = time.time()
        st['resume'].pop(key, None)
    else:
        st['watched'].pop(key, None)
        st['resume'].pop(key, None)
    save_state(st)
    xbmc.executebuiltin('Container.Refresh')


# ------------------------------------------------------- reprodução e controle
def flat_episodes(series_id):
    flat = []
    for sk, lst in get_episodes(series_id).items():
        for e in lst:
            flat.append((to_int(sk), to_int(e.get('episode_num')), sk, e))
    flat.sort(key=lambda x: (x[0], x[1]))
    return flat


def neighbor(params, delta):
    """Devolve os parâmetros do próximo (+1) ou anterior (-1) item, ou None."""
    kind = params.get('kind')
    if kind == 'ep':
        series_id = params.get('series')
        eps = get_episodes(series_id)
        flat = []
        for sk, lst in eps.items():
            for e in lst:
                flat.append((to_int(sk), to_int(e.get('episode_num')), sk, e))
        flat.sort(key=lambda x: (x[0], x[1]))
        ids = [str(x[3].get('id')) for x in flat]
        if str(params.get('id')) not in ids:
            return None
        i = ids.index(str(params.get('id'))) + delta
        if i < 0 or i >= len(flat):
            return None
        _, _, sk, e = flat[i]
        return ep_params(e, sk, series_id, params.get('sname', ''))
    if kind == 'live':
        cat = params.get('cat')
        data = as_list(api_cached('get_live_streams', category_id=cat) if cat
                       else api_cached('get_live_streams'))
        data.sort(key=lambda c: to_int(c.get('num')))
        ids = [str(c.get('stream_id')) for c in data]
        if str(params.get('id')) not in ids:
            return None
        i = (ids.index(str(params.get('id'))) + delta) % len(data)   # volta ao início/fim
        c = data[i]
        return play_params('live', c.get('stream_id'), live_ext(), c.get('name') or 'Sem nome',
                           c.get('stream_icon'), cat=cat)
    return None


def step(delta):
    cur = load_state().get('current') or {}
    if not cur:
        notify('Nada em reprodução.')
        return
    nxt = neighbor(cur, delta)
    if not nxt:
        if cur.get('kind') == 'vod':
            notify('Filmes não têm próximo item.')
        else:
            notify('Não há %s.' % ('próximo episódio' if delta > 0 else 'episódio anterior'))
        return
    notify(nxt['title'])
    xbmc.executebuiltin('PlayMedia(%s)' % play_link(nxt))


class Tracker(xbmc.Player):
    def __init__(self):
        xbmc.Player.__init__(self)
        self.ended = False
        self.stopped = False

    def onPlayBackEnded(self):
        self.ended = True

    def onPlayBackStopped(self):
        self.stopped = True


def track(params, url):
    key = key_of(params['kind'], params['id'])
    mon = xbmc.Monitor()
    pl = Tracker()
    t0 = time.time()
    while not mon.abortRequested() and not pl.isPlaying() and time.time() - t0 < 40:
        mon.waitForAbort(0.5)
    if not pl.isPlaying():
        return
    last_pos, total, last_save = 0, 0, time.time()
    switched = False
    while not mon.abortRequested() and not pl.ended and not pl.stopped:
        if pl.isPlaying():
            try:
                if not pl.getPlayingFile().startswith(url.split('|')[0]):
                    switched = True      # outro item assumiu o player
                    break
                last_pos = pl.getTime()
                total = pl.getTotalTime()
            except Exception:
                pass
            if total > 0 and time.time() - last_save >= 10 and last_pos >= MIN_RESUME:
                st = load_state()
                st['resume'][key] = {'pos': last_pos, 'total': total, 'ts': time.time(), 'params': params}
                save_state(st)
                last_save = time.time()
        mon.waitForAbort(2)

    done = pl.ended or (total > 0 and last_pos / total >= WATCHED_AT)
    st = load_state()
    if done:
        st['watched'][key] = time.time()
        st['resume'].pop(key, None)
    elif last_pos >= MIN_RESUME and total > 0:
        st['resume'][key] = {'pos': last_pos, 'total': total, 'ts': time.time(), 'params': params}
    else:
        st['resume'].pop(key, None)
    save_state(st)

    if pl.ended and params['kind'] == 'ep' and ADDON.getSetting('autonext') != 'false':
        nxt = neighbor(params, 1)
        if not nxt:
            notify('Fim da série.')
            return
        stop = xbmcgui.Dialog().yesno('Próximo episódio', nxt['title'],
                                      nolabel='Reproduzir agora', yeslabel='Parar', autoclose=10000)
        if not stop:
            xbmc.executebuiltin('PlayMedia(%s)' % play_link(nxt))
    elif not switched:
        xbmc.executebuiltin('Container.Refresh')


def play():
    p = {k: ARGS.get(k, '') for k in ('kind', 'id', 'ext', 'title', 'icon', 'series', 'season', 'cat', 'sname')}
    kind = p['kind']
    if kind == 'live' and not p['ext']:
        p['ext'] = live_ext()
    url = stream_url(kind, p['id'], p['ext'])
    li = xbmcgui.ListItem(label=p['title'], path=url)
    if p['icon']:
        li.setArt({'thumb': p['icon'], 'icon': p['icon']})
    try:
        li.getVideoInfoTag().setTitle(p['title'])
    except Exception:
        li.setInfo('video', {'title': p['title']})

    key = key_of(kind, p['id'])
    st = load_state()
    r = st['resume'].get(key)
    if kind != 'live' and r and r.get('pos', 0) >= MIN_RESUME:
        start = int(r['pos'])
        if ADDON.getSetting('ask_resume') != 'false':
            choice = xbmcgui.Dialog().contextmenu(['Retomar de %s' % fmt_time(start), 'Começar do início'])
            if choice == -1:
                xbmcplugin.setResolvedUrl(HANDLE, False, li)
                return
            if choice == 1:
                start = 0
        if start:
            li.setProperty('StartOffset', str(start))

    st['current'] = p
    save_state(st)
    xbmcplugin.setResolvedUrl(HANDLE, True, li)
    if kind != 'live':
        track(p, url)


def account():
    data = api(None)
    ui = data.get('user_info') if isinstance(data, dict) else None
    if not ui:
        xbmcgui.Dialog().ok('Diva IPTV', 'Não consegui ler os dados da conta. Confira servidor, porta, '
                            'usuário e senha nas configurações.')
        return
    try:
        exp = time.strftime('%d/%m/%Y', time.localtime(int(ui.get('exp_date')))) if ui.get('exp_date') else 'sem data'
    except Exception:
        exp = str(ui.get('exp_date'))
    auth = 'sim' if str(ui.get('auth')) == '1' else 'NÃO (usuário ou senha recusados)'
    msg = ('Login válido: %s\nSituação: %s\nVencimento: %s\nConexões em uso: %s de %s'
           % (auth, ui.get('status', '?'), exp, ui.get('active_cons', '?'), ui.get('max_connections', '?')))
    xbmcgui.Dialog().ok('Minha conta', msg)


def vtuple(v):
    return tuple(to_int(x) for x in str(v).split('.'))


def update():
    import zipfile
    import tempfile
    url = ADDON.getSetting('update_url').strip()
    if not url:
        xbmcgui.Dialog().ok('Atualizar addon', 'Coloque o link do arquivo version.json no campo '
                            '"Link de atualização" das configurações do addon.')
        ADDON.openSettings()
        return
    try:
        req = urllib.request.Request(url, headers={'User-Agent': user_agent()})
        with urllib.request.urlopen(req, timeout=30) as r:
            info = json.loads(r.read().decode('utf-8', 'replace'))
        new, zurl = str(info['version']), info['zip']
    except Exception as e:
        notify('Não consegui verificar: %s' % e, True)
        return
    cur = ADDON.getAddonInfo('version')
    if vtuple(new) <= vtuple(cur):
        xbmcgui.Dialog().ok('Atualizar addon', 'Você já está na versão mais recente (%s).' % cur)
        return
    if not xbmcgui.Dialog().yesno('Atualizar addon', 'Versão nova disponível: %s (a sua é %s).\nAtualizar agora?' % (new, cur)):
        return
    try:
        tmp = os.path.join(tempfile.gettempdir(), 'diva_update.zip')
        req = urllib.request.Request(zurl, headers={'User-Agent': user_agent()})
        with urllib.request.urlopen(req, timeout=60) as r, open(tmp, 'wb') as f:
            f.write(r.read())
        dest = xbmcvfs.translatePath('special://home/addons/')
        with zipfile.ZipFile(tmp) as z:
            names = z.namelist()
            if not names or any(not n.startswith(ADDON_ID + '/') for n in names):
                raise ValueError('arquivo de atualização inválido')
            z.extractall(dest)
        os.remove(tmp)
        xbmc.executebuiltin('UpdateLocalAddons')
        xbmcgui.Dialog().ok('Atualizar addon', 'Atualizado para a versão %s.\nFeche o Kodi e abra de novo.' % new)
    except Exception as e:
        notify('Falha ao atualizar: %s' % e, True)


def play_now(p):
    xbmc.executebuiltin('PlayMedia(%s)' % play_link(p))


def menu():
    cur = load_state().get('current') or {}
    if not cur:
        notify('Nada em reprodução.')
        return
    kind = cur.get('kind')
    opts = []
    if kind == 'ep':
        opts += [('next', 'Próximo episódio'), ('prev', 'Episódio anterior'),
                 ('list', 'Lista de episódios'), ('seen', 'Marcar como assistido')]
    elif kind == 'live':
        opts += [('next', 'Próximo canal'), ('prev', 'Canal anterior'), ('list', 'Lista de canais')]
    else:
        opts += [('seen', 'Marcar como assistido')]
    opts += [('pause', 'Pausar / Continuar'), ('osd', 'Mostrar barra de controle'), ('stop', 'Parar')]
    heading = cur.get('title') or 'Diva IPTV'
    if cur.get('sname'):
        heading = '%s - %s' % (cur['sname'], heading)
    choice = xbmcgui.Dialog().select(heading, [o[1] for o in opts])
    if choice < 0:
        return
    act = opts[choice][0]
    if act == 'next':
        step(1)
    elif act == 'prev':
        step(-1)
    elif act == 'pause':
        xbmc.executebuiltin('PlayerControl(Play)')
    elif act == 'osd':
        xbmc.executebuiltin('ActivateWindow(videoosd)')
    elif act == 'stop':
        xbmc.executebuiltin('PlayerControl(Stop)')
    elif act == 'seen':
        st = load_state()
        key = key_of(kind, cur['id'])
        st['watched'][key] = time.time()
        st['resume'].pop(key, None)
        save_state(st)
        notify('Marcado como assistido.')
    elif act == 'list':
        if kind == 'ep':
            flat = flat_episodes(cur.get('series'))
            labels = ['T%s E%s - %s' % (x[2], x[1], x[3].get('title') or 'Episódio') for x in flat]
            pre = next((i for i, x in enumerate(flat) if str(x[3].get('id')) == str(cur['id'])), -1)
            i = xbmcgui.Dialog().select('Episódios', labels, preselect=pre)
            if i >= 0:
                _, _, sk, e = flat[i]
                play_now(ep_params(e, sk, cur.get('series'), cur.get('sname', '')))
        else:
            cat = cur.get('cat')
            data = as_list(api_cached('get_live_streams', category_id=cat) if cat
                           else api_cached('get_live_streams'))
            data.sort(key=lambda c: to_int(c.get('num')))
            labels = [c.get('name') or 'Sem nome' for c in data]
            pre = next((i for i, c in enumerate(data) if str(c.get('stream_id')) == str(cur['id'])), -1)
            i = xbmcgui.Dialog().select('Canais', labels, preselect=pre)
            if i >= 0:
                c = data[i]
                play_now(play_params('live', c.get('stream_id'), live_ext(), c.get('name') or 'Sem nome',
                                     c.get('stream_icon'), cat=cat))


# ---------------------------------------------------------------- roteamento
mode = ARGS.get('mode')
if mode is None:
    root()
elif mode == 'settings':
    ADDON.openSettings()
elif mode == 'continue':
    continue_list()
elif mode == 'live_cats':
    categories('get_live_categories', 'live_list', 'live.png')
elif mode == 'live_list':
    live_list(ARGS.get('cat'))
elif mode == 'vod_cats':
    categories('get_vod_categories', 'vod_list', 'movies.png')
elif mode == 'vod_list':
    vod_list(ARGS.get('cat'))
elif mode == 'series_cats':
    categories('get_series_categories', 'series_list', 'series.png')
elif mode == 'series_list':
    series_list(ARGS.get('cat'))
elif mode == 'seasons':
    seasons(ARGS.get('series'), ARGS.get('sname', ''))
elif mode == 'episodes':
    episodes(ARGS.get('series'), ARGS.get('season'), ARGS.get('sname', ''))
elif mode == 'play':
    play()
elif mode == 'mark':
    mark()
elif mode == 'next':
    step(1)
elif mode == 'prev':
    step(-1)
elif mode == 'menu':
    menu()
elif mode == 'account':
    account()
elif mode == 'update':
    update()
